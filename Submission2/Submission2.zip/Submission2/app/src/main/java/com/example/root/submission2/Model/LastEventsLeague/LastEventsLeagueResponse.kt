package com.example.root.submission2.Model.LastEventsLeague

data class LastEventsLeagueResponse (val events:List<LastEventsLeague>)
