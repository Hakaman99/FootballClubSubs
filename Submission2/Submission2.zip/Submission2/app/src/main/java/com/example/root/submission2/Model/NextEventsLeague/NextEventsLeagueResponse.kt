package com.example.root.submission2.Model.NextEventsLeague

data class NextEventsLeagueResponse(
        val events:List<NextEventsLeague>
)