package com.example.root.submission2.Model.LookUpTeam

data class LookUpTeamResponse(val teams:List<LookUpTeam>)