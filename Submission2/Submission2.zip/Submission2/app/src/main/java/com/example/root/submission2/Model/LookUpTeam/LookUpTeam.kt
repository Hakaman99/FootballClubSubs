package com.example.root.submission2.Model.LookUpTeam

import com.google.gson.annotations.SerializedName

data class LookUpTeam (
        @SerializedName("strTeamBadge")
        val teamBadge:String
)